<pre>
<?php
$data = array(
  "dst" => $_POST['dst'],
  "popup" => $_POST['popup'],
  "username" => $_POST['username'],
  "password" => $_POST['password']
  );
$p = json_encode($data, JSON_PRETTY_PRINT);
echo $p;
?>
</pre>