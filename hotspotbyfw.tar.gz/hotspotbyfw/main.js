function submit(){
  document.login.password.value = document.getElementById("pass").value;
  document.login.submit();
  
}

function doLogin(){/* Start function doLogin()*/
  const pass = document.getElementById("pass").value;
  if(pass !== null && pass !== ''){/*Start pass verify*/
    if(pass === "sayang"){/*Start pass verified sayang*/
    Swal.fire({
  title: "Hp ke wifi aja saling terhubung<br/> Kita kapan?",
  showDenyButton: true,
  confirmButtonText: "Sekarang aja",
  denyButtonText: `Kapan"`
}).then((result) => {/*Start result function*/
  if (result.isConfirmed) {
    submit();
  } else if (result.isDenied) {
    Swal.fire({
  title: "Ya Kapan?",
  confirmButtonText: "Sekarang Deh",
  icon: "question"
  }).then((result) => {
    if(result.isConfirmed){
      return submit();
    }
  })
  }
/*END result function*/});
/*END pass verified*/}else{
  Swal.fire({
      title: "ketik <code>sayang</code>, bukan <code>"+document.getElementById('pass').value+"</code>",
      icon: "info"
    })
}
  /*END pass verify*/}else{
    Swal.fire({
      title: "Isi dulu sayang!",
      confirmButtonText: "iya",
      icon: "info"
    })
}
/*END function doLogin()*/}

    function openLogout() {
	if (window.name != 'hotspot_status') return true;
        open('$(link-logout)', 'hotspot_logout', 'toolbar=0,location=0,directories=0,status=0,menubars=0,resizable=1,width=280,height=250');
	window.close();
	return false;
    }
    
function doLogout(){
  Swal.fire({
    title: "Cukup wifi saja yang terputus<br/>Hubungan kita jangan xixixi:v",
    confirmButtonText: "Lanjut",
    showDenyButton: true,
    denyButtonText: "Batal"
  }).then((result) => {
    if(result.isConfirmed){
      document.logout.submit();
    }else if(result.isDenied){
      alert("OK");
    }
  })
}