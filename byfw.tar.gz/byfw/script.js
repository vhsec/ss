var i = 0,
  text;
text =
  "Ikhlas bukan melepaskan sesuatu dengan air mata, tapi bisa merelakan sesuatu dengan senyuman";
var u = 0,
  text2;
text2 = "- Smile :)";

function showDiv() {
  document.getElementById("Content").style.display = "block";
}
function trm() {
  document.getElementById("trm").style.margin = "0";
}
function play() {
  var audio = new Audio("music.mp3");
  audio.play();
}
play();
function ketik() {
  if (i < text.length) {
    document.getElementById("text").innerHTML += text.charAt(i);
    i++;
    setTimeout(ketik, 100);
  }
  if (i == text.length) {
    ketikk();
  }
}
ketik();
showDiv();
function ketikk() {
  if (u < text2.length) {
    document.getElementById("text2").innerHTML += text2.charAt(u);
    u++;
    setTimeout(ketikk, 200);
  }

  if (u == text2.length) {
    trm();
  }
}

function putus(){
  
}
